#!/bin/sh

# stop all openvpn processes

killall -TERM openvpn
