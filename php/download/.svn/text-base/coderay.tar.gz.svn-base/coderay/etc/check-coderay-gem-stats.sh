curl http://gems.rubyforge.org/stats.html 2>/dev/null | grep -n ">coderay<"
