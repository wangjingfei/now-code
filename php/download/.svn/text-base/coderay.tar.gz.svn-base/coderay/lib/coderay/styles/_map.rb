module CodeRay
module Styles
  
  default :alpha
  
end
end
