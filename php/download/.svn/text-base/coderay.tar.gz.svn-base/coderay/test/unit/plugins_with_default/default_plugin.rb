class DefaultPlugin < PluginScannerTest::PluginsWithDefault::Plugin
  
  register_for :default_plugin
  
end
