class Example < PluginScannerTest::Plugins::Plugin
  
  register_for :example
  title 'The Example'
  
end
