class UserPlugin < PluginScannerTest::Plugins::Plugin
  
  register_for :user_plugin
  
end
