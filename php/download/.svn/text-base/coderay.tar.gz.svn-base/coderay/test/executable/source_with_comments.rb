# a class
class ClassName
end
